package com.maco.followthebeat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowTheBeatApplicationTests {

    @Test
    void contextLoads() {
    }

}
